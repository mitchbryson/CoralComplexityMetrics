========================================================
“complexitymetrics”: A free command line tool for computing
multi-scale structural complexity metrics on triangulated
Digital surface models
========================================================

Author: Mitch Bryson (m.bryson@acfr.usyd.edu.au)
Date: 23/01/2018
Version 1.0.0

==============================
About:

“complexitymetrics” is a free command line tool that computes
a variety of structural complexity metrics over triangulated 
surface models of landscapes, constructed for example by using
structure from motion. It accepts models in ply format and allows 
the user to specify regularly spaced square quadrats for which
different measurements can be made. The program returns a csv 
formatted file which contains metrics including mean rugosity, 
mean and variance of height, mean slope and distribution of slope 
angles and topographic surface area. The software allows the user 
to specify a list of measurement scales (spatial resolutions) at
which calculations are performed, allowing for the derivation of
size-dependant complexity parameters such as fractal dimension.

“complexitymetrics” is released under a GNU General Public Licence
that allows you to freely distribute and modify to code to suit your 
needs (see “LICENCE.txt for more details).

==============================
Use:

complexitymetrics <plyfile> <quadrat_size> <spacing> <output_dir> <Quad Keep Area Ratio Threshold [optional]> <resolutions.txt [optional]>

plyfile: a triangulated surface model in ply format.

quadrat_size: size of quadrats (linear distance along one side
of a square quadrat)

spacing: distance between centres of quadrats

output_dir: name of directory to create and output results

Quad Keep Area Ratio Threshold [optional, default 0.9]: Specifies
the minimum 2D surface area of data present in a quadratic for it
to be part of the output set (as a fraction of the square quadratic 
area)

resolutions.txt [optional]: a text file containing a a list of 
terrain resolutions at which calculations are performed. If this
Option is not specified, calculations are performed only at the 
original mesh resolution.

==============================
Future Development:

“complexitymetrics” will eventually be expanded into a GUI version
with the ability to calculate a variety of different metrics, accept
a variety of mesh input formats, output values in different formats.

Source code for the software will be released in a future version.

==============================
Acknowledgements:

“complexitymetrics” was developed as part of a collaboration between
researchers at the Australian Centre for Field Robotics (Dr. Mitch 
Bryson) and the School of Life and Environmental Sciences (Gus Porter
And Prof. Will Figueira).

